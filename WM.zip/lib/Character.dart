import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class Character {
  final String? id;
  final String? name;
  final String? imageUrl;
  final String? details;

  Character({this.id, this.name, this.imageUrl, this.details});

  factory Character.fromJson(Map<String, dynamic> json) {
    return Character(
      id: json['id'],
      name: json['name'],
      imageUrl: json['image'],
      details: json['details'],
    );
  }
}

class CharacterListPage extends StatefulWidget {
  @override
  _CharacterListPageState createState() => _CharacterListPageState();
}

class _CharacterListPageState extends State<CharacterListPage> {
  List<Character> characters = [];

  @override
  void initState() {
    super.initState();
    loadJsonData();
  }

  // Load JSON data from assets
  Future<void> loadJsonData() async {
    final String response =
        await rootBundle.loadString('assets/character.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      characters = data.map((item) => Character.fromJson(item)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ข้อมูลตัวละคร',
          style: GoogleFonts.itim(fontSize: 22, color: Color(0xff000000)),
        ),
      ),
      body: characters.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: characters.length,
              itemBuilder: (context, index) {
                final character = characters[index];
                return Card(
                  color: Color(0xff1b1b1b),
                  elevation: 10,
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              CharacterDetailPage(character: character),
                        ),
                      );
                    },
                    leading: character.imageUrl!.startsWith('http')
                        ? Image.network(character.imageUrl!, width: 100)
                        : Image.asset(character.imageUrl!, width: 100),
                    title: Text(
                      'ประเภทตัวละคร : ${character.id}',
                      style: GoogleFonts.itim(
                          fontSize: 15, color: Color(0xff5bffc4)),
                    ),
                    subtitle: Text(
                      character.name ?? '',
                      style: GoogleFonts.itim(fontSize: 20, color: Colors.blue),
                    ),
                    trailing: Icon(
                      Icons.arrow_forward_ios,
                      color: Color(0xffff5640),
                    ),
                  ),
                );
              },
            ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context);
        },
        backgroundColor: Colors.grey[300],
        child: Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
      ),
    );
  }
}

class CharacterDetailPage extends StatelessWidget {
  final Character character;

  const CharacterDetailPage({super.key, required this.character});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1b1b1b),
      appBar: AppBar(
        title: Text(
          'ข้อมูลตัวละคร',
          style: GoogleFonts.k2d(fontSize: 18),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            character.imageUrl!.startsWith('http')
                ? Image.network(character.imageUrl!, width: 180)
                : Image.asset(character.imageUrl!, width: 180),
            SizedBox(height: 20),
            Text(
              'ชื่อ: ${character.name} \nประเภทตัวละคร: ${character.id} \nข้อมูลตัวละคร: ${character.details}',
              style: GoogleFonts.k2d(fontSize: 20, color: Color(0xff5bffc4)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context);
        },
        backgroundColor: Colors.grey[300],
        child: Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
      ),
    );
  }
}
