import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ContentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1b1b1b), // Dark background color
      appBar: AppBar(
        backgroundColor: Colors.white, // White app bar background
        elevation: 0,
        title: Text(
          'เนื้อเรื่อง', // Title text
          style: GoogleFonts.itim(
            fontSize: 20,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Text(
          'ยังไม่มีเนื้อเรื่อง', // "No content yet" message
          style: GoogleFonts.itim(
            fontSize: 18,
            color: Color(0xff5bffc4), // Green color for the text
          ),
        ),
      ),
    );
  }
}
